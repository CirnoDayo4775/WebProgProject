<?php

include dirname(__DIR__)."/../mainSystem/connectDB.php";

$pid = mysqli_real_escape_string($con, $_POST["prodid"]);
$prodname = mysqli_real_escape_string($con, $_POST["prodName"]);
$prodprice = mysqli_real_escape_string($con, $_POST["prodDPrice"]);




    echo $pid.$prodname.$prodprice;



    $sql = "UPDATE productlist 
    SET prodName = '{$prodname}',
        prodDPrice = '{$prodprice}'
    WHERE prodid = '{$pid}'";

if ($con->query($sql)) {
    echo "completed";
    header("Location: showdatatable.php");
    exit();
} else {
    echo "Error: " . $con->error;
}


    ?>