<?php

include dirname(__DIR__)."/../mainSystem/connectDB.php";

    $pid = $_GET["pid"];

    $sql = "DELETE FROM productlist WHERE prodid = '{$pid}'";

    print ($con->query($sql));


    if ($con->query($sql)) {
        echo "completed";
        header("Location: showdatatable.php");
    } else {
        echo "Error: " . $con->error;
    }
    
    $con->close();
    ?>