<?php
session_start();
include 'connectDB.php';

// Read data from form
$username = $_POST['username'];
$password = $_POST['password'];
$Conpassword = $_POST['Conpassword'];
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];

// Check if passwords match
if ($password != $Conpassword) {
    // Redirect with error message or handle the error appropriately
    header("location:../HTML-BASE-VER/V3/sign_up.html?error=password_mismatch");
    exit(); // Stop further execution
}

// Check if the username already exists
$sql = "SELECT * FROM userdata WHERE username = '$username'";
$result = $con->query($sql);
$count_row = mysqli_num_rows($result);

if ($count_row != 0) {
    // Redirect with error message or handle the error appropriately
    header("location:../HTML-BASE-VER/V3/sign_up.html?error=username_exists");
    exit(); // Stop further execution
}

// Insert new user into the database
$sql = "INSERT INTO `userdata` (`username`, `password`, `userFirstName`, `UserLastName`) 
        VALUES ('$username', '$password', '$FirstName', '$LastName')";

if ($con->query($sql)) {
    // Set session variable for the username
    $_SESSION['username'] = $username;
    // Redirect to the home page or a success page
    header("location:../HTML-BASE-VER/V3/HomeV2.php");
    exit(); // Stop further execution
} else {
    // Handle the error appropriately, maybe redirect with an error message
    header("location:../HTML-BASE-VER/V3/sign_up.html?error=registration_failed");
    exit(); // Stop further execution
}

$con->close();
?>
