<?php
session_start();
include 'connectDB.php';

// Read data from form
$name = $_POST['name'];
$price = $_POST['price'];

// Check if image file is uploaded
if(isset($_FILES['image'])){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name'];
    $file_type=$_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false){
        $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    
    if($file_size > 2097152) { // 2MB limit
        $errors[]='File size must be less than 2 MB';
    }
    
    if(empty($errors)==true) {
        // Move the uploaded file to the specified directory
        move_uploaded_file($file_tmp,"../product/".$file_name);
        echo "Success";
    }else{
        print_r($errors);
    }
}

// Insert product into the database
$sql = "INSERT INTO `productlist` (`prodName`, `prodDPrice`, `prodShowImg`) 
        VALUES ('$name', '$price', '$file_name')";

if ($con->query($sql)) {
    // Redirect to the home page or a success page
    header("location:../HTML-BASE-VER/V3/showdatatable.php");
    exit(); // Stop further execution
} else {
    // Handle the error appropriately, maybe redirect with an error message
    header("location:../HTML-BASE-VER/V3/addproduct.html?error=registration_failed");
    exit(); // Stop further execution
}

$con->close();
?>
